/*
 * 幻灯片 构造函数
 */
function Slider(){
	this.focusViewId = "";
	this.focusTextId = "";
	this.focusSliderId = "";
	this.sliderNum = "";
	this.Num = 0;
	this.Prev = "";
	this.Next = "";
	this.upMove = false;
	this.listEvent = "onmouseover";
	this.OsObject = "";
};
Slider.prototype = {
	version: "1.20",
	author: "jzy",
	initialize: function(){
		var thisTemp = this;
		if (!this.focusViewId) {
			throw new Error("必须指定focusViewId.");
			return;
		};
		if (!this.focusSliderId) {
			throw new Error("必须指定focusSliderId.");
			return;
		};
		this.aImg = this._$(this.focusViewId).getElementsByTagName('li');
		if (this.focusTextId != "" && this.focusTextId != "none") {
			this.aTxt = this._$(this.focusTextId).getElementsByTagName('li');
		} else {
			this.aTxt = null;
		}
		this.aSmg = this._$(this.focusSliderId).getElementsByTagName('li');
		this.aaImg = this._$(this.focusViewId).getElementsByTagName('img');
		this.aaSmg = this._$(this.focusSliderId).getElementsByTagName('img');
		this.oUl = this._$(this.focusSliderId).getElementsByTagName('ul')[0];
		if (this.sliderNum != "" && this.sliderNum != "none") {
			this.oSliderNum = this._$(this.sliderNum);
		}else {
			this.oSliderNum = null;
		}
	   	this.oPrev = this._$(this.Prev);
	    this.oNext = this._$(this.Next);
		
		this.intCountNext = 0;
		this.intCountPre = new Number();
		this.sListEvent = this.listEvent.substr(2);
		if (this.oSliderNum != null) {
			this.oSliderNum.innerHTML = 1 + '/' + this.aSmg.length;
		}
		this.aWid = this.upMove ? 'height': 'width';
		this.aMarLeft = this.upMove ? 'marginTop': 'marginLeft';
		this.aSmgNum = this.aSmg.length - this.Num;
		this.aSmgWid = this.getStyle(this.aSmg[0], this.aWid);
		this.aSmgWid = parseInt(this.aSmgWid.substr(0, (this.aSmgWid.length - 2)));
		this.oUl.style[this.aWid] = this.aSmg.length * this.aSmgWid + "px";
		this.oUlMarLeft = parseInt(this.oUl.style[this.aMarLeft])?parseInt(this.oUl.style[this.aMarLeft]): 0;
		for (var i = 0; i < this.aSmg.length; i++) {
			this.aSmg[i].index = i;
			this.aImg[i].index = i;
			this.addEvent(this.aSmg[i], this.sListEvent, (function(d){
	　			return function(){thisTemp.fn.call(d)};
			})(this.aSmg[i]));
		};
		
		this.fn = function(){
			for (var n = 0; n < thisTemp.aSmg.length; n++) {
				thisTemp.aSmg[n].className = '';
				if (thisTemp.aTxt != null) {
					thisTemp.aTxt[n].className = '';
				}
				thisTemp.startMove(thisTemp.aImg[n], 'opacity', 0);
				thisTemp.aImg[n].style.zIndex = 1;
			};
			thisTemp.aSmg[this.index].className = 'current';
			if (thisTemp.aTxt != null) {
				thisTemp.aTxt[this.index].className = 'show';
			}
			if (thisTemp.oSliderNum != null) {
				thisTemp.oSliderNum.innerHTML = (this.index + 1) + '/' + thisTemp.aSmg.length;
			}
			thisTemp.startMove(thisTemp.aImg[this.index], 'opacity', 100);
			thisTemp.aImg[this.index].style.zIndex = 2;
		};
		
		this.addEvent(this.oPrev, "mouseover", function(){
			if (!thisTemp.oUlMarLeft) {
				thisTemp.intCountPre = 0;
	        }else{
				thisTemp.intCountPre = Math.ceil(Math.abs(thisTemp.oUlMarLeft / thisTemp.aSmgWid));
			}			
		});
		this.addEvent(this.oPrev, "click", function(){
			if (thisTemp.aSmg.length <= thisTemp.Num) {
				return;
			}
			else {
				thisTemp.intCountPre--;
				if (thisTemp.intCountPre >= 0) {
					var aLeft = -thisTemp.aSmgWid * thisTemp.intCountPre;
					thisTemp.oUlMarLeft = aLeft;
					thisTemp.startMove(thisTemp.oUl, thisTemp.aMarLeft, aLeft);
				}
				else {
					thisTemp.oUlMarLeft = 0;
					thisTemp.startMove(thisTemp.oUl, thisTemp.aMarLeft, 0);
					return;
				}
			}	
		});
		
		this.addEvent(this.oNext, "mouseover", function(){
			if (!thisTemp.oUlMarLeft) {
				thisTemp.intCountNext = 0;
	        }else{
				thisTemp.intCountNext = Math.ceil(Math.abs(thisTemp.oUlMarLeft / thisTemp.aSmgWid));
			}			
		});
		this.addEvent(this.oNext, "click", function(){
			if (thisTemp.aSmg.length <= thisTemp.Num) {
				return;
			}
			else {
				thisTemp.intCountNext++;
				if (thisTemp.intCountNext <= thisTemp.aSmgNum) {
					var aLeft = -thisTemp.aSmgWid * thisTemp.intCountNext;
					thisTemp.oUlMarLeft = aLeft;
					thisTemp.startMove(thisTemp.oUl, thisTemp.aMarLeft, aLeft);
				}
				else {
					thisTemp.oUlMarLeft = -thisTemp.aSmgNum * thisTemp.aSmgWid;
					thisTemp.startMove(thisTemp.oUl, thisTemp.aMarLeft, -thisTemp.aSmgNum * thisTemp.aSmgWid);
					return;
				}
			}
		});
	},
	startMove: function(obj, attr, iTarget){
		var thisTemp = this;
        clearInterval(obj.timer);
        obj.timer = setInterval(function(){
        	thisTemp.doMove(obj, attr, iTarget);
        }, 20);
    },
    doMove: function(obj, attr, iTarget){
        var iCur = 0;
        if (attr == 'opacity') {
            iCur = parseInt(100 * this.getStyle(obj, attr)) || 0;
        }
        else {
            iCur = parseInt(this.getStyle(obj, attr)) || 0;
        }
        var iSpeed = (iTarget - iCur) / 8;
        iSpeed = (iSpeed > 0) ? Math.ceil(iSpeed) : Math.floor(iSpeed);
		//alert(iTarget);
		//_$("aa").innerHTML += "iSpeed= " + iSpeed +" ::: "+"iCur= " + iCur + " ::: " + "iTarget= " + iTarget + "<br /><br />";
        if (iCur == iTarget) {
            clearInterval(obj.timer);
        } else if (attr == 'opacity') {
			obj.style.filter = 'alpha(opacity=' + (iCur + iSpeed) + ')';
			obj.style.opacity = (iCur + iSpeed) / 100;
		} else {
			obj.style[attr] = iCur + iSpeed + 'px';
		}
    },
    _$: function(objectId) {
	  	if(document.getElementById && document.getElementById(objectId)) {
			// W3C DOM
			return document.getElementById(objectId);
		} else if (document.all && document.all(objectId)) {
			// MSIE 4 DOM
			return document.all(objectId);
		} else if (document.layers && document.layers[objectId]) {
			// NN 4 DOM.. note: this won't find nested layers
			return document.layers[objectId];
		} else {
			return false;
	  	}
	},
	getStyle: function(obj, attr){
        if (obj.currentStyle) {
            return obj.currentStyle[attr];
        }
		else if(window.getComputedStyle){
            return window.getComputedStyle(obj, false)[attr];
        }
    },
	isIE: navigator.appVersion.indexOf("MSIE") != -1 ? true: false,
	//isIE6: navigator.appVersion.indexOf("MSIE 6.0") != -1 ? true: false,
	isIE6: !window.XMLHttpRequest,
	getEbyTag: function(obj, oTag) {
		return obj.getElementsByTagName(oTag);
    },
    getEbyClass: function(obj, tag, className) {
        var reArray = [];
        var target = obj.getElementsByTagName(tag);
        for (i = 0; i < target.length; i++) {
            if (target[i].className == className) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	setClassName: function(obj, oClassName, state) {
		var temp;
		temp = obj.className;
		if (state == 'add') {
			if (temp) {
				temp += " " + oClassName;
			} else {
				temp = oClassName;
			}
		} else {
			if (temp) {
				temp = temp.replace(oClassName, '');
			} else {
				return
			}	
		};
		obj.className = temp
	},
	getChildNodes: function(obj) {
        var reArray = [];
        var target = obj.childNodes;
        for (i = 0; i < target.length; i++) {
            if (target[i].nodeType == 1) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	getChildNodesByTag: function(obj, tag) {
        var reArray = [];
		tag = tag.toUpperCase();
        var target = obj.childNodes;
        for (i = 0; i < target.length; i++) {
            if (target[i].nodeName == tag) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	insertAfter: function(newObj, targetObj){
		var parent = targetObj.parentNode;
		if (parent.lastChild == targetObj) {
			parent.appendChild(newObj);
		} else {
			parent.insertBefore(newObj, targetObj.nextSibling);
		}

	},
	getNextSibling: function(obj){
		var tempObj = obj.nextSibling;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.nextSibling;
		};
		return tempObj;
	},
	getPrevSibling: function(obj){
		var tempObj = obj.previousSibling;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.previousSibling;
		};
		return tempObj;
	},
	getFirstChild: function(obj){
		var tempObj = obj.firstChild;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.nextSibling;
		};
		return tempObj;
	},
	getLastChild: function(obj){
		var tempObj = obj.lastChild;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.previousSibling;
		};
		return tempObj;
	},
	addEvent: function(obj, eventType, func) {
		if (obj.attachEvent) {
			obj.attachEvent("on" + eventType, func)
		} else {
			obj.addEventListener(eventType, func, false)
		}
	},
	delEvent: function(obj, eventType, func) {
		if (obj.detachEvent) {
			obj.detachEvent("on" + eventType, func)
		} else {
			obj.removeEventListener(eventType, func, false)
		}
	},
	addEnLeaEvent: function(obj, eventType, func){
		if (obj.attachEvent) {
			obj.attachEvent("on" + eventType, func)
		} else {
			if (eventType == "mouseenter"){
				obj.addEventListener("mouseover", this.withinElement(func), false)
			} else if (eventType == "mouseleave"){
				obj.addEventListener("mouseleave", this.withinElement(func), false)
			}
		}
	},
	withinElement: function(func){
		return function (e) {
		  var parent = e.relatedTarget;
		  while (parent && parent != this) {
			try {parent = parent.parentNode;}
			catch(e) {break;}
		  }
		  if (parent != this) {
			func.call(this, e);
		  }
		}
	},
	getOs: function(){ 
	   var OsObject = ""; 
	   if(navigator.userAgent.indexOf("MSIE")>0) { 
	        this.OsObject = "MSIE"; 
	   } 
	   if(isFirefox=navigator.userAgent.indexOf("Firefox")>0){ 
	        this.OsObject =  "Firefox"; 
	   } 
	   if(isSafari=navigator.userAgent.indexOf("Safari")>0) { 
			this.OsObject =  "Safari"; 
	   } 
	   if(isCamino=navigator.userAgent.indexOf("Camino")>0){ 
	        this.OsObject =  "Camino"; 
	   } 
	   if(isMozilla=navigator.userAgent.indexOf("Gecko")>0){ 
	        this.OsObject =  "Gecko"; 
	   }  
	}
};