//图片持续匀速滚动构造函数
function Rolling() {
	this.scrollContId = "";
	this.circularly = true;
	this.frameWidth = 0;
	this.speed = 20;
	this.space = 20;
	this.upright = false;
	this.scrollTimeObj;
	this.stripDiv = document.createElement("DIV");
	this.lDiv01 = document.createElement("DIV");
	this.lDiv02 = document.createElement("DIV");
	
};
Rolling.prototype = {
	version: "1.00",
	author: "jzy",
	initialize: function() {
		var thisTemp = this;
		if (!this.scrollContId) {
			throw new Error("必须指定scrollContId.");
			return
		};

		this.scDiv = this._$(this.scrollContId);
		if (!this.scDiv) {
			throw new Error("scrollContId不是正确的对象.(scrollContId = \"" + this.scrollContId + "\")");
			return
		};

		this.scDiv.style[this.upright ? 'height': 'width'] = this.frameWidth + "px";
		this.scDiv.style.overflow = "hidden";
		this.lDiv01.innerHTML = this.scDiv.innerHTML;
		this.scDiv.innerHTML = "";
		this.scDiv.appendChild(this.stripDiv);
		this.stripDiv.appendChild(this.lDiv01);
		this.stripDiv.style.overflow = "hidden";
		this.stripDiv.style.zoom = "1";
		this.stripDiv.style[this.upright ? 'height': 'width'] = "4560px";
		this.lDiv01.style.overflow = "hidden";
		this.lDiv01.style.zoom = "1";
		
		if (this.circularly) {
			this.stripDiv.appendChild(this.lDiv02);
			this.lDiv02.innerHTML = this.lDiv01.innerHTML;
			this.lDiv02.style.overflow = "hidden";
			this.lDiv02.style.zoom = "1";
		};

		if (!this.upright) {
			this.lDiv01.style.cssFloat = "left";
			this.lDiv01.style.styleFloat = "left"
		};
		if (this.circularly && !this.upright) {
			this.lDiv02.style.cssFloat = "left";
			this.lDiv02.style.styleFloat = "left"
		};
		this.scDiv[this.upright ? 'scrollTop': 'scrollLeft'] = 0;
		this.scroll = this.upright ? 'scrollTop': 'scrollLeft';
		this.sWidth = this.upright ? 'scrollHeight': 'scrollWidth';
		this.addEvent(this.scDiv, "mouseover",
			function() {
				thisTemp.stop()
		});
		this.addEvent(this.scDiv, "mouseout",
			function() {
				thisTemp.play()
		});
		this.scrollTimeObj = setInterval(function() {
			thisTemp.moveLeft();
		}, this.speed);
	},
	moveLeft: function() {
		if (this.circularly) {
			if (this.scDiv[this.scroll] + this.space >= this.lDiv01[this.sWidth]) {
				this.scDiv[this.scroll] = this.scDiv[this.scroll] + this.space - this.lDiv01[this.sWidth];
				//this._$("jzy").innerHTML += this.scDiv[this.scroll] +" == ";
			} else {
				this.scDiv[this.scroll] += this.space;
			}
		} else {
			if (this.scDiv[this.scroll] + this.space >= this.lDiv01[this.sWidth] - this.frameWidth) {
				this.scDiv[this.scroll] = this.lDiv01[this.sWidth] - this.frameWidth;
				this.stop();
			} else {
				this.scDiv[this.scroll] += this.space
			}
		};
	},
	moveRight: function() {
		if (this.circularly) {
			if (this.scDiv[this.scroll] - this.space <= 0) {
				this.scDiv[this.scroll] = this.lDiv01[this.sWidth] + this.scDiv[this.scroll] - this.space;
				//this._$("jzy").innerHTML += this.scDiv[this.scroll] +" == ";
			} else {
				this.scDiv[this.scroll] -= this.space
			}
		} else {
			if (this.scDiv[this.scroll] - this.space <= 0) {
				this.scDiv[this.scroll] = 0;
				this.stop();
			} else {
				this.scDiv[this.scroll] -= this.space
			}
		};
	},
	play: function() {
		var thisTemp = this;
		this.scrollTimeObj = setInterval(function() {
			thisTemp.moveLeft();
		}, this.speed)
	},
	stop: function() {
		clearInterval(this.scrollTimeObj)
	},
    _$: function(objectId) {
	  	if(document.getElementById && document.getElementById(objectId)) {
			// W3C DOM
			return document.getElementById(objectId);
		} else if (document.all && document.all(objectId)) {
			// MSIE 4 DOM
			return document.all(objectId);
		} else if (document.layers && document.layers[objectId]) {
			// NN 4 DOM.. note: this won't find nested layers
			return document.layers[objectId];
		} else {
			return false;
	  	}
	},
	getStyle: function(obj, attr){
        if (obj.currentStyle) {
            return obj.currentStyle[attr];
        }
		else if(window.getComputedStyle){
            return window.getComputedStyle(obj, false)[attr];
        }
    },
	isIE: navigator.appVersion.indexOf("MSIE") != -1 ? true: false,
	//isIE6: navigator.appVersion.indexOf("MSIE 6.0") != -1 ? true: false,
	isIE6: !window.XMLHttpRequest,
	getEbyTag: function(obj, oTag) {
		return obj.getElementsByTagName(oTag);
    },
    getEbyClass: function(obj, tag, className) {
        var reArray = [];
        var target = obj.getElementsByTagName(tag);
        for (i = 0; i < target.length; i++) {
            if (target[i].className == className) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	setClassName: function(obj, oClassName, state) {
		var temp;
		temp = obj.className;
		if (state == 'add') {
			if (temp) {
				temp += " " + oClassName;
			} else {
				temp = oClassName;
			}
		} else {
			if (temp) {
				temp = temp.replace(oClassName, '');
			} else {
				return
			}	
		};
		obj.className = temp
	},
	getChildNodes: function(obj) {
        var reArray = [];
        var target = obj.childNodes;
        for (i = 0; i < target.length; i++) {
            if (target[i].nodeType == 1) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	getChildNodesByTag: function(obj, tag) {
        var reArray = [];
		tag = tag.toUpperCase();
        var target = obj.childNodes;
        for (i = 0; i < target.length; i++) {
            if (target[i].nodeName == tag) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	insertAfter: function(newObj, targetObj){
		var parent = targetObj.parentNode;
		if (parent.lastChild == targetObj) {
			parent.appendChild(newObj);
		} else {
			parent.insertBefore(newObj, targetObj.nextSibling);
		}

	},
	getNextSibling: function(obj){
		var tempObj = obj.nextSibling;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.nextSibling;
		};
		return tempObj;
	},
	getPrevSibling: function(obj){
		var tempObj = obj.previousSibling;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.previousSibling;
		};
		return tempObj;
	},
	getFirstChild: function(obj){
		var tempObj = obj.firstChild;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.nextSibling;
		};
		return tempObj;
	},
	getLastChild: function(obj){
		var tempObj = obj.lastChild;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.previousSibling;
		};
		return tempObj;
	},
	addEvent: function(obj, eventType, func) {
		if (obj.attachEvent) {
			obj.attachEvent("on" + eventType, func)
		} else {
			obj.addEventListener(eventType, func, false)
		}
	},
	delEvent: function(obj, eventType, func) {
		if (obj.detachEvent) {
			obj.detachEvent("on" + eventType, func)
		} else {
			obj.removeEventListener(eventType, func, false)
		}
	},
	addEnLeaEvent: function(obj, eventType, func){
		if (obj.attachEvent) {
			obj.attachEvent("on" + eventType, func)
		} else {
			if (eventType == "mouseenter"){
				obj.addEventListener("mouseover", this.withinElement(func), false)
			} else if (eventType == "mouseleave"){
				obj.addEventListener("mouseleave", this.withinElement(func), false)
			}
		}
	},
	withinElement: function(func){
		return function (e) {
		  var parent = e.relatedTarget;
		  while (parent && parent != this) {
			try {parent = parent.parentNode;}
			catch(e) {break;}
		  }
		  if (parent != this) {
			func.call(this, e);
		  }
		}
	},
	getOs: function(){ 
	   var OsObject = ""; 
	   if(navigator.userAgent.indexOf("MSIE")>0) { 
	        this.OsObject = "MSIE"; 
	   } 
	   if(isFirefox=navigator.userAgent.indexOf("Firefox")>0){ 
	        this.OsObject =  "Firefox"; 
	   } 
	   if(isSafari=navigator.userAgent.indexOf("Safari")>0) { 
			this.OsObject =  "Safari"; 
	   } 
	   if(isCamino=navigator.userAgent.indexOf("Camino")>0){ 
	        this.OsObject =  "Camino"; 
	   } 
	   if(isMozilla=navigator.userAgent.indexOf("Gecko")>0){ 
	        this.OsObject =  "Gecko"; 
	   }  
	}
};