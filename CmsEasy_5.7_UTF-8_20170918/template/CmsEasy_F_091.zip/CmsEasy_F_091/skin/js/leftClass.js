/*
 * 下拉导航样式
 */
function leftNavEve(navId)
{
	this.leftNavId = navId;
	this.initialize();
}

leftNavEve.prototype = {
	version: "1.00",
	author: "jzy",
	initialize: function(){
		var thisTemp = this;
		if (!this.leftNavId) {
			throw new Error("必须指定leftNavId.");
			return
		}
		
		$("#" + thisTemp.leftNavId).find("h5").find("a").click(function(){
			var t = $(this).parent(), b = t.next(".isClassTwo"), p = t.parent(), n = b.length;
			if (n != 0) {
				if (b.is(":visible")) {
					b.slideUp("fast");
					p.removeClass("active");
				} else {
					b.slideDown("fast");
					p.addClass("active");
				}
			} else {
				p.addClass("active_fir");
			}
			
			p.siblings("li").removeClass("active active_fir").find(".isClassTwo").slideUp("fast");
		})
	}
}