$(document).ready(function(){



	$('.function01 a').mouseover(function(){
	$(this).stop().animate({"top":"-165px"}, 200); 
	})

	$('.function02 a').mouseover(function(){
	$(this).stop().animate({"top":"-164px"}, 200); 
	})

	$('.function03 a').mouseover(function(){
	$(this).stop().animate({"top":"-124px"}, 200); 
	})
		$('.function04 a').mouseover(function(){
	$(this).stop().animate({"top":"-149px"}, 200); 
	})

		$('.function05 a').mouseover(function(){
	$(this).stop().animate({"top":"-149px"}, 200); 
	})

		$('.function06 a').mouseover(function(){
	$(this).stop().animate({"top":"-100px"}, 200); 
	})

		$('.function07 a').mouseover(function(){
	$(this).stop().animate({"top":"-100px"}, 200); 
	})

		$('.function08 a').mouseover(function(){
	$(this).stop().animate({"top":"-100px"}, 200); 
	})

		$('.function09 a').mouseover(function(){
	$(this).stop().animate({"top":"-270px"}, 200); 
	})

		$('.function10 a').mouseover(function(){
	$(this).stop().animate({"top":"-100px"}, 200); 
	})

		$('.function11 a').mouseover(function(){
	$(this).stop().animate({"top":"-100px"}, 200); 
	})


	$('.function a').mouseout(function(){
	$(this).stop().animate({"top":"0"}, 200); 
	})
})