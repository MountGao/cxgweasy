/*
 * sim_select 类
 */
function sim_select(selId) {
	this.selId = selId;
	if (!this.selId){
		throw new Error("必须指定this.selId.");
		return
	}
	var thisTemp = this;
	this.obj = this._$(this.selId);
	this.obj.style.display = 'none';
	var opts = this.obj.options;
	var parent = this.obj.parentNode;
	this.isShow = false;
	this.div = document.createElement('div');
	this.ul = document.createElement('ul');
	this.h3 = document.createElement('h3');
	this.div.className = 'sim_select';
	parent.replaceChild(this.div, this.obj);
	this.div.appendChild(this.obj);
	this.ul.style.display = 'none';
	this.h3.innerHTML = opts[this.obj.selectedIndex].innerHTML;

	for (var i = 0, l = this.obj.length; i < l; i++) {
		var li = document.createElement('li');
		li.innerHTML = opts[i].innerHTML;
		li.index = i;
		//li.setAttribute("val",opts[i].getAttribute("value"));
		this.ul.appendChild(li);
		li.onmouseover = function() {
			this.className += ' over'
		};
		li.onmouseout = function() {
			this.className = this.className.replace(/over/gi, '')
		};
		li.onclick = function() {
			thisTemp.hide();
			thisTemp.h3.innerHTML = this.innerHTML;
			//thisTemp.obj.value = this.getAttribute("val");
			opts[this.index].setAttribute("selected", "selected");
		};
	};
	this.div.appendChild(this.h3);
	this.div.appendChild(this.ul);
	this.ul.style.width = (parent.offsetWidth - 2) + 'px';
	this.ul.style.position = "absolute";
	var ulBorWid = parseInt(this.getStyle(parent, 'borderLeftWidth'));
	if (ulBorWid > 0) {
		this.ul.style.left = -ulBorWid + 'px';
	} else {
		this.ul.style.left = 0 + 'px';
	}
	this.ul.style.top = this.h3.offsetHeight + 'px';
	this.ul.style.zIndex = 2;
	this.init();
};
sim_select.prototype = {
	version: "1.00",
	author: "jzy",
	init: function(){
		var thisTemp = this;
		this.addEvent(document.documentElement, 'click', function(e){
			thisTemp.close(e);
		});
		this.h3.onclick = function(){
			thisTemp.toggles();
		}
	},
	show: function(){
		this.ul.style.display = 'block';
		this.isShow = true;
	},
	hide: function(){
		this.ul.style.display = 'none';
		this.isShow = false;
	},
	close: function(e){
		var t = window.event ? window.event.srcElement : e.target;//事件源对象,被该事件绑定的对象
		do {
			if (t == this.div) {
				return
			}
			else 
				if (t == document.documentElement) {
					this.hide();
					return
				}
				else {
					t = t.parentNode;
					if (!t) {
						break;
					}
				}
		}
		while (t.parentNode)
	},
	toggles: function(){
		this.isShow ? this.hide() : this.show()
	},
	_$: function(objectId) {
	  	if(document.getElementById && document.getElementById(objectId)) {
			// W3C DOM
			return document.getElementById(objectId);
		} else if (document.all && document.all(objectId)) {
			// MSIE 4 DOM
			return document.all(objectId);
		} else if (document.layers && document.layers[objectId]) {
			// NN 4 DOM.. note: this won't find nested layers
			return document.layers[objectId];
		} else {
			return false;
	  	}
	},
	getStyle: function(obj, attr){
        if (obj.currentStyle) {
            return obj.currentStyle[attr];
        }
		else if(window.getComputedStyle){
            return window.getComputedStyle(obj, false)[attr];
        }
    },
	isIE: navigator.appVersion.indexOf("MSIE") != -1 ? true: false,
	//isIE6: navigator.appVersion.indexOf("MSIE 6.0") != -1 ? true: false,
	isIE6: !window.XMLHttpRequest,
	getEbyTag: function(obj, oTag) {
		return obj.getElementsByTagName(oTag);
    },
    getEbyClass: function(obj, tag, className) {
        var reArray = [];
        var target = obj.getElementsByTagName(tag);
        for (i = 0; i < target.length; i++) {
            if (target[i].className == className) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	setClassName: function(obj, oClassName, state) {
		var temp;
		temp = obj.className;
		if (state == 'add') {
			if (temp) {
				temp += " " + oClassName;
			} else {
				temp = oClassName;
			}
		} else {
			if (temp) {
				temp = temp.replace(oClassName, '');
			} else {
				return
			}	
		};
		obj.className = temp
	},
	getChildNodes: function(obj) {
        var reArray = [];
        var target = obj.childNodes;
        for (i = 0; i < target.length; i++) {
            if (target[i].nodeType == 1) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	getChildNodesByTag: function(obj, tag) {
        var reArray = [];
		tag = tag.toUpperCase();
        var target = obj.childNodes;
        for (i = 0; i < target.length; i++) {
            if (target[i].nodeName == tag) {
                reArray.push(target[i]);
            }
        }
        return reArray;
    },
	insertAfter: function(newObj, targetObj){
		var parent = targetObj.parentNode;
		if (parent.lastChild == targetObj) {
			parent.appendChild(newObj);
		} else {
			parent.insertBefore(newObj, targetObj.nextSibling);
		}

	},
	getNextSibling: function(obj){
		var tempObj = obj.nextSibling;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.nextSibling;
		};
		return tempObj;
	},
	getPrevSibling: function(obj){
		var tempObj = obj.previousSibling;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.previousSibling;
		};
		return tempObj;
	},
	getFirstChild: function(obj){
		var tempObj = obj.firstChild;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.nextSibling;
		};
		return tempObj;
	},
	getLastChild: function(obj){
		var tempObj = obj.lastChild;
		while (tempObj.nodeType != 1){
			tempObj = tempObj.previousSibling;
		};
		return tempObj;
	},
	addEvent: function(obj, eventType, func) {
		if (obj.attachEvent) {
			obj.attachEvent("on" + eventType, func)
		} else {
			obj.addEventListener(eventType, func, false)
		}
	},
	delEvent: function(obj, eventType, func) {
		if (obj.detachEvent) {
			obj.detachEvent("on" + eventType, func)
		} else {
			obj.removeEventListener(eventType, func, false)
		}
	},
	addEnLeaEvent: function(obj, eventType, func){
		if (obj.attachEvent) {
			obj.attachEvent("on" + eventType, func)
		} else {
			if (eventType == "mouseenter"){
				obj.addEventListener("mouseover", this.withinElement(func), false)
			} else if (eventType == "mouseleave"){
				obj.addEventListener("mouseleave", this.withinElement(func), false)
			}
		}
	},
	withinElement: function(func){
		return function (e) {
		  var parent = e.relatedTarget;
		  while (parent && parent != this) {
			try {parent = parent.parentNode;}
			catch(e) {break;}
		  }
		  if (parent != this) {
			func.call(this, e);
		  }
		}
	},
	getOs: function(){ 
	   var OsObject = ""; 
	   if(navigator.userAgent.indexOf("MSIE")>0) { 
	        this.OsObject = "MSIE"; 
	   } 
	   if(isFirefox=navigator.userAgent.indexOf("Firefox")>0){ 
	        this.OsObject =  "Firefox"; 
	   } 
	   if(isSafari=navigator.userAgent.indexOf("Safari")>0) { 
			this.OsObject =  "Safari"; 
	   } 
	   if(isCamino=navigator.userAgent.indexOf("Camino")>0){ 
	        this.OsObject =  "Camino"; 
	   } 
	   if(isMozilla=navigator.userAgent.indexOf("Gecko")>0){ 
	        this.OsObject =  "Gecko"; 
	   }  
	}
}